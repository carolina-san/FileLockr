'use strict'


const config=require('./config');
const express=require('express');
const logger=require('morgan');
const mongojs=require ('mongojs');
const cors= require('cors');
var fs=require('fs');
var https=require('https');
const helmet=require('helmet');
const tokenHelper = require('./helpers/token.helper'); 
const passHelper= require('./helpers/pass.helper');
const moment = require('moment'); 

const port=config.PORT;
const urlDB=config.DB;
const accessToken=config.TOKEN;

const app=express();
const db=mongojs(urlDB); 
const id=mongojs.ObjectID;


var allowCrossTokenOrigin=(req,res,next)=>{
    res.header("Access-Control-Allow-Origin","*");
    return next();
};

var allowCrossTokenMethods=(req,res,next)=>{
    res.header("Access-Control-Allow-Methods","*");
    return next();
};

var allowCrossTokenHeaders=(req,res,next)=>{
    res.header("Access-Control-Allow-Headers","*");
    return next();
};

var auth =(req,res,next)=>{
    if(!req.headers.authorization){
        return res.status(401).send({
            result:'KO',
            message:'Cabecera de autenticación Bearer no encontrada'
        });
    };
    const token=req.headers.authorization.split(' ')[1];
    if(!token){
        return res.status(401).send({
            result:'KO',
            message:'Token de acceso JWT no encontrado'
        });
    };
    tokenHelper.decodificaToken(token)
        .then(userID=> {
    
            req.user ={
                id:userID,
                token:token
            };
            
            return next(); 
        })
        .catch(response => {
            res.status(response.status);
            res.json({
                result:'KO',
                message:response.message
            });
            
        });
};

app.use(logger('dev'));
app.use(express.urlencoded({extended:false}));
app.use(express.json());
app.use(cors());
app.use(allowCrossTokenOrigin);                                                                                                                              
app.use(allowCrossTokenMethods);                                                                                    
app.use(allowCrossTokenHeaders);
app.use(helmet());


app.get('/api/user',auth,(req,res,next)=>{

    db.user.find((err,coleccion)=>{
        if(err) return res.status(500).json({result:'KO',msg:err});
        res.json(coleccion);
    });
});
app.get('/api/auth',auth,(req,res,next)=>{
    db.user.find({},{"name":1, "email":2,"_id":0}, (err, coleccion) => {
        if (err) return res.status(500).json({ result: 'KO', msg: err });
        res.json(coleccion);
    });
});

app.get('/api/user/:id',auth,(req,res,next)=>{
    const elementoId=req.params.id;
    db.user.findOne({_id: id(elementoId)},(err,elementoRecuperado)=>{
        if (err) return res.status(500).json({result:'KO',msg:err});
        res.json(elementoRecuperado);
    });
});

app.get('/api/auth/me',auth,(req,res,next)=>{
    const elementoId=req.user.id;
    db.user.findOne({_id: id(elementoId)},(err,elementoRecuperado)=>{
        if (err) return res.status(500).json({result:'KO',msg:err});
        //res.json(elementoRecuperado);
        res.json({ result: 'OK' ,usuario:elementoRecuperado})
    });
});

app.post('/api/user',auth,(req,res,next)=>{
    const nuevoElemento=req.body;
    db.user.save(nuevoElemento, (err,coleccionGuardada)=>{
        if (err) return res.status(500).json({result:'KO',msg:err});
        res.json(coleccionGuardada);
    });
});

app.post('/api/auth/reg',(req,res,next)=>{
    const nuevoElemento=req.body;
    if(!req.body.name){
        return res.status(401).send({
            result:'KO',
            message:'Nombre de usuario no encontrado'
        });
    };
    if(!req.body.email){
        return res.status(401).send({
            result:'KO',
            message:'Dirección de correo no encontrada'
        });
    };
    
    if(!req.body.pass){
        return res.status(401).send({
            result:'KO',
            message:'Contraseña no encontrada'
        });
    };
    db.user.findOne({email: req.body.email},(err,elementoEncontrado)=>{
        if (err) {
            return res.status(500).json({ result: 'KO', message: 'Error al buscar usuario' });
        }

        if (elementoEncontrado) {
            return res.status(401).json({ result: 'KO', message: 'Ya hay un usuario con ese correo' });
        }
        
        const miPass=req.body.pass;
        const usuario={
            email: req.body.email,
            displayName: req.body.name,
            password: miPass,
            signupDate: moment().unix(),
            lastLogin: moment().unix()
        };
        passHelper.encriptaPassword(usuario.password).then(hash=>{
            
            usuario.password=hash;
            
            db.user.save(usuario, (err, coleccionGuardada) => {
                if (err) {
                    return res.status(500).json({ result: 'KO', message: 'Error al guardar usuario' });
                }
                
                const token = tokenHelper.creaToken(usuario);
                res.json({ result: 'OK', message: 'Usuario registrado exitosamente', token ,usuario});
                
            });
        });
    });
});


app.post('/api/auth',(req,res,next)=>{
    const nuevoElemento=req.body;
    
    if(!req.body.email){
        return res.status(401).send({
            result:'KO',
            message:'Dirección de correo no encontrada'
        });
    };
    
    if(!req.body.pass){
        return res.status(401).send({
            result:'KO',
            message:'Contraseña no encontrada'
        });
    };
    db.user.findOne({email: req.body.email},(err,elementoEncontrado)=>{
        if (err) {
            return res.status(500).json({ result: 'KO', message: 'Error al buscar usuario' });
        }

        if (elementoEncontrado) {
            const miPass=req.body.pass;
            const usuario=elementoEncontrado;
            usuario.lastLogin=moment().unix();
            
                passHelper.comparaPassword(miPass,usuario.password).then(passOK=>{
                if(!passOK){
                    return res.status(500).json({ result: 'KO', message: 'La contraseña no es correcta' });
                }
                
                db.user.update(
                    {email: req.body.email},
                    {$set:{lastLogin:moment().unix()}},
                    {multi:true},
                    (err,result)=>{
                    if(err) return  res.status(500).json({result: 'KO', message: 'Error al guardar usuario'});
                        const token = tokenHelper.creaToken(usuario);
                        res.json({ result: 'OK', message: 'Sesión iniciada correctamente', token ,usuario});
                    });
            });
            
        
        }
        else{
            return res.status(401).json({ result: 'KO', message: 'No hay ningún usuario con ese correo' });
        }
        
    });
});


app.put('/api/user/:id',auth,(req,res,next)=>{
    const elementoId=req.params.id;
    const nuevosRegistros= req.body;
    db.user.update(
        {_id: id(elementoId)},
        {$set: nuevosRegistros},
        {safe: true,multi:false},
        (err,result)=>{
            if(err) return  res.status(500).json({result:'KO',msg:err});
            res.json(result);
    });
});

app.delete('/api/user/:id',auth,(req,res,next)=>{
    const elementoId=req.params.id;

    db.user.remove({_id:id(elementoId)},(err,resultado)=>{
        if(err) return res.status(500).json({result:'KO',msg:err});
        res.json(resultado);    
    });
});

https.createServer({
    cert:fs.readFileSync('./cert/cert.pem'),
    key: fs.readFileSync('./cert/key.pem')
},app).listen(port,()=>{
    console.log('API RESTful AUTH ejecutándose en https://localhost:${port}/api/user/{id}');
});